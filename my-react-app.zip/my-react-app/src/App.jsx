import React, { useState, useEffect } from 'react';
import { Container, CssBaseline, ThemeProvider, createTheme, Snackbar, Alert } from '@mui/material';
import Calendar from './components/Calendar';
import EventForm from './components/EventForm';
import { format, parseISO, isSameDay } from 'date-fns';
import { calendarDB } from './services/db';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1a73e8',
      light: '#4285f4',
      dark: '#1557b0',
    },
    secondary: {
      main: '#34a853',
      light: '#4caf50',
      dark: '#2e7d32',
    },
    background: {
      default: '#f8f9fa',
      paper: '#ffffff',
    },
    text: {
      primary: '#202124',
      secondary: '#5f6368',
    },
    error: {
      main: '#ea4335',
    },
    warning: {
      main: '#fbbc05',
    },
    info: {
      main: '#4285f4',
    },
    success: {
      main: '#34a853',
    },
  },
  typography: {
    fontFamily: '"Google Sans", "Roboto", "Helvetica", "Arial", sans-serif',
    h6: {
      fontWeight: 500,
      color: '#202124',
    },
    subtitle1: {
      color: '#5f6368',
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          borderRadius: '8px',
          padding: '8px 16px',
          fontWeight: 500,
        },
        contained: {
          boxShadow: 'none',
          '&:hover': {
            boxShadow: '0 1px 2px rgba(60,64,67,0.3), 0 1px 3px 1px rgba(60,64,67,0.15)',
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
        },
      },
    },
    MuiDialog: {
      styleOverrides: {
        paper: {
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: '8px',
            '&:hover .MuiOutlinedInput-notchedOutline': {
              borderColor: '#1a73e8',
            },
          },
        },
      },
    },
  },
  shape: {
    borderRadius: 8,
  },
  shadows: [
    'none',
    '0 1px 2px rgba(60,64,67,0.3), 0 1px 3px 1px rgba(60,64,67,0.15)',
    // ... rest of the shadows
  ],
});

const App = () => {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState(null);

  // Add checkForConflicts function
  const checkForConflicts = (eventData, excludeEventId = null) => {
    return events.filter(event => {
      if (event.id === excludeEventId) return false;
      
      try {
        // Safely parse dates
        const eventDate = new Date(event.date);
        const newEventDate = new Date(eventData.date);
        
        if (!isSameDay(eventDate, newEventDate)) return false;
        
        // If either event doesn't have time, they conflict
        if (!eventData.time || !event.time) return true;
        
        // Parse times for comparison
        const [start1, end1] = eventData.time.split(' - ').map(t => t.trim());
        const [start2, end2] = event.time.split(' - ').map(t => t.trim());
        
        // Validate time format
        if (!start1 || !end1 || !start2 || !end2) return true;
        
        // Check for overlap
        return (start1 <= end2 && end1 >= start2);
      } catch (error) {
        console.error('Error checking conflicts:', error);
        return true; // If there's an error parsing, consider it a conflict
      }
    });
  };

  // Load events from IndexedDB on component mount
  useEffect(() => {
    const loadEvents = async () => {
      try {
        await calendarDB.init(); // Ensure database is initialized
        const loadedEvents = await calendarDB.getEvents();
        if (Array.isArray(loadedEvents)) {
          setEvents(loadedEvents);
        }
      } catch (error) {
        console.error('Error loading events:', error);
        setSnackbarMessage('Error loading events from database');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
      } finally {
        setIsLoading(false);
      }
    };

    loadEvents();
  }, []);

  // Save events to IndexedDB whenever they change
  useEffect(() => {
    const saveEvents = async () => {
      if (!isLoading && events.length > 0) {
        try {
          await calendarDB.saveEvents(events);
        } catch (error) {
          console.error('Error saving events:', error);
          setSnackbarMessage('Error saving events to database');
          setSnackbarSeverity('error');
          setSnackbarOpen(true);
        }
      }
    };

    saveEvents();
  }, [events, isLoading]);

  const handleAddEvent = () => {
    setSelectedEvent(null);
    setIsFormOpen(true);
  };

  const handleEditEvent = (event) => {
    setSelectedEvent(event);
    setIsFormOpen(true);
  };

  const handleEventSubmit = async (eventData) => {
    try {
      // Validate date
      if (!eventData.date) {
        setSnackbarMessage('Date is required');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
        return;
      }

      // Ensure date is in proper format
      try {
        const date = new Date(eventData.date);
        if (isNaN(date.getTime())) {
          setSnackbarMessage('Invalid date format');
          setSnackbarSeverity('error');
          setSnackbarOpen(true);
          return;
        }
        // Convert to ISO string for consistent format
        eventData.date = date.toISOString();
      } catch (error) {
        setSnackbarMessage('Invalid date format');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
        return;
      }

      // Ensure time is properly formatted
      if (eventData.time) {
        const [start, end] = eventData.time.split(' - ').map(t => t.trim());
        if (!start || !end) {
          setSnackbarMessage('Invalid time format. Please use format: "HH:MM - HH:MM"');
          setSnackbarSeverity('error');
          setSnackbarOpen(true);
          return;
        }
      }

      const conflicts = checkForConflicts(eventData, selectedEvent?.id);
      
      if (conflicts.length > 0) {
        setSnackbarMessage(`Warning: This event conflicts with ${conflicts.length} other event(s) on the same day`);
        setSnackbarSeverity('warning');
        setSnackbarOpen(true);
      }

      if (selectedEvent) {
        // Update existing event
        await calendarDB.updateEvent(eventData);
        setEvents(prevEvents =>
          prevEvents.map(event =>
            event.id === eventData.id ? { ...eventData, date: new Date(eventData.date).toISOString() } : event
          )
        );
        setSnackbarMessage('Event updated successfully');
      } else {
        // Add new event
        const newEvent = {
          ...eventData,
          id: Date.now().toString(), // Ensure unique ID
          date: new Date(eventData.date).toISOString() // Ensure consistent date format
        };
        await calendarDB.addEvent(newEvent);
        setEvents(prevEvents => [...prevEvents, newEvent]);
        setSnackbarMessage('Event added successfully');
      }
      setSnackbarSeverity('success');
      setSnackbarOpen(true);
      setIsFormOpen(false);
      setSelectedEvent(null);
    } catch (error) {
      console.error('Error handling event submission:', error);
      setSnackbarMessage('Error saving event: ' + error.message);
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  };

  const handleEventDrop = async (eventId, sourceDate, destinationDate, isDeletion = false) => {
    try {
      if (isDeletion) {
        await calendarDB.deleteEvent(eventId);
        setEvents(prevEvents => 
          prevEvents.filter(event => event.id !== eventId)
        );
        setSnackbarMessage('Event deleted successfully');
      } else if (destinationDate) {
        const updatedEvent = events.find(event => event.id === eventId);
        if (updatedEvent) {
          const newEvent = { ...updatedEvent, date: destinationDate };
          await calendarDB.updateEvent(newEvent);
          setEvents(prevEvents =>
            prevEvents.map(event =>
              event.id === eventId ? newEvent : event
            )
          );
          setSnackbarMessage('Event moved successfully');
        }
      }
      setSnackbarSeverity('success');
      setSnackbarOpen(true);
    } catch (error) {
      console.error('Error handling event drop:', error);
      setSnackbarMessage('Error updating event');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  };

  const handleDayClick = (date) => {
    setSelectedEvent(null);
    setIsFormOpen(true);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container 
        maxWidth="xl" 
        sx={{ 
          py: 4,
          background: 'linear-gradient(135deg, #f8f9fa 0%, #e8f0fe 100%)',
          minHeight: '100vh'
        }}
      >
        <Calendar
          events={events}
          onDayClick={handleDayClick}
          onEventDrop={handleEventDrop}
          onAddEvent={handleAddEvent}
          onEditEvent={handleEditEvent}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
        />
        <EventForm
          open={isFormOpen}
          onClose={() => {
            setIsFormOpen(false);
            setSelectedEvent(null);
          }}
          onSubmit={handleEventSubmit}
          event={selectedEvent}
        />
        <Snackbar
          open={snackbarOpen}
          autoHideDuration={4000}
          onClose={() => setSnackbarOpen(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setSnackbarOpen(false)} 
            severity={snackbarSeverity}
            sx={{ width: '100%' }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Container>
    </ThemeProvider>
  );
};

export default App;
