import React, { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, addMonths, subMonths, startOfWeek, endOfWeek, isSameDay, isToday, parseISO, addDays } from 'date-fns';
import { 
  Paper, 
  Grid, 
  Typography, 
  IconButton, 
  Box,
  useTheme,
  useMediaQuery,
  TextField,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Tooltip,
  Snackbar,
  Alert,
  Chip,
  Menu,
  MenuItem,
  FormControl,
  Select,
  InputLabel,
  CircularProgress
} from '@mui/material';
import { 
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  Add as AddIcon,
  Search as SearchIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Warning as WarningIcon,
  FilterList as FilterListIcon,
  Clear as ClearIcon,
  ViewWeek as ViewWeekIcon,
  CalendarViewMonth as CalendarViewMonthIcon,
  Sync as SyncIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon
} from '@mui/icons-material';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { googleCalendarService } from '../services/googleCalendar';

const EVENT_CATEGORIES = [
  'All',
  'Work',
  'Personal',
  'Meeting',
  'Appointment',
  'Other'
];

const Calendar = ({ events, onDayClick, onEventDrop, onAddEvent, onEditEvent, selectedCategory }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightedDate, setHighlightedDate] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedDateForDelete, setSelectedDateForDelete] = useState(null);
  const [eventToDelete, setEventToDelete] = useState(null);
  const [conflictDialogOpen, setConflictDialogOpen] = useState(false);
  const [conflictInfo, setConflictInfo] = useState(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [viewMode, setViewMode] = useState('month'); // 'month' or 'week'
  const [syncDialogOpen, setSyncDialogOpen] = useState(false);
  const [syncStatus, setSyncStatus] = useState('idle'); // 'idle', 'syncing', 'success', 'error'
  const [isGoogleCalendarInitialized, setIsGoogleCalendarInitialized] = useState(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  // Get the first day of the month
  const firstDayOfMonth = startOfMonth(currentDate);
  // Get the last day of the month
  const lastDayOfMonth = endOfMonth(currentDate);
  // Get the first day of the week that contains the first day of the month
  const firstDayOfCalendar = startOfWeek(firstDayOfMonth);
  // Get the last day of the week that contains the last day of the month
  const lastDayOfCalendar = endOfWeek(lastDayOfMonth);
  // Get all days between first and last day of calendar
  const daysInCalendar = eachDayOfInterval({ start: firstDayOfCalendar, end: lastDayOfCalendar });

  const handlePrevMonth = () => setCurrentDate(prev => subMonths(prev, 1));
  const handleNextMonth = () => setCurrentDate(prev => addMonths(prev, 1));

  const checkForConflicts = (eventId, destinationDate) => {
    const eventToMove = events.find(e => e.id === eventId);
    if (!eventToMove) return [];

    const conflicts = events.filter(event => {
      if (event.id === eventId) return false;
      if (!isSameDay(parseISO(event.date), parseISO(destinationDate))) return false;
      
      // If either event doesn't have time, they conflict
      if (!eventToMove.time || !event.time) return true;
      
      try {
        // Parse times for comparison
        const [start1, end1] = eventToMove.time.split(' - ').map(t => t.trim());
        const [start2, end2] = event.time.split(' - ').map(t => t.trim());
        
        // Validate time format
        if (!start1 || !end1 || !start2 || !end2) return true;
        
        // Check for overlap
        return (start1 <= end2 && end1 >= start2);
      } catch (error) {
        console.error('Error parsing time:', error);
        return true; // If there's an error parsing time, consider it a conflict
      }
    });

    return conflicts;
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const sourceDate = result.source.droppableId;
    const destinationDate = result.destination.droppableId;
    const eventId = result.draggableId;

    const conflicts = checkForConflicts(eventId, destinationDate);
    
    if (conflicts.length > 0) {
      setConflictInfo({
        eventId,
        sourceDate,
        destinationDate,
        conflicts
      });
      setConflictDialogOpen(true);
    } else {
      onEventDrop(eventId, sourceDate, destinationDate);
      setSnackbarMessage('Event moved successfully');
      setSnackbarOpen(true);
    }
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setHighlightedDate(null);
      return;
    }

    // Find the first event that matches the search query
    const matchingEvent = events.find(event => 
      (event.title.toLowerCase().includes(query.toLowerCase()) ||
      event.description?.toLowerCase().includes(query.toLowerCase())) &&
      (selectedCategory === 'All' || event.category === selectedCategory)
    );

    if (matchingEvent) {
      const eventDate = new Date(matchingEvent.date);
      setCurrentDate(eventDate);
      setHighlightedDate(eventDate);
    } else {
      setHighlightedDate(null);
    }
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    setFilterAnchorEl(null);
    
    // If there's a search query, reapply the search with the new category
    if (searchQuery.trim()) {
      handleSearch(searchQuery);
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setHighlightedDate(null);
  };

  const filteredEvents = events.filter(event => {
    try {
      const eventDate = new Date(event.date);
      const matchesSearch = !searchQuery.trim() || 
        event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        event.description?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategory === 'All' || event.category === selectedCategory;
      
      return matchesSearch && matchesCategory;
    } catch (error) {
      console.error('Error filtering event:', error);
      return false;
    }
  });

  const handleDayClick = (day) => {
    const eventsOnDay = events.filter(event => 
      format(new Date(event.date), 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd')
    );

    if (eventsOnDay.length > 0) {
      setSelectedDateForDelete(day);
      setDeleteDialogOpen(true);
    } else {
      onDayClick(day);
    }
  };

  const handleAddEventOnDate = (day, e) => {
    e.stopPropagation(); // Prevent triggering the day click
    onDayClick(day);
  };

  const handleDeleteEvents = () => {
    if (selectedDateForDelete) {
      const dateStr = format(selectedDateForDelete, 'yyyy-MM-dd');
      const updatedEvents = events.filter(event => 
        format(new Date(event.date), 'yyyy-MM-dd') !== dateStr
      );
      onEventDrop(null, dateStr, null, true); // Pass true to indicate deletion
      setDeleteDialogOpen(false);
      setSelectedDateForDelete(null);
    }
  };

  const handleCloseDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setEventToDelete(null);
  };

  const handleEventDelete = (event, e) => {
    e.stopPropagation(); // Prevent triggering the day click
    setEventToDelete(event);
    setDeleteDialogOpen(true);
  };

  const handleDeleteEvent = () => {
    if (eventToDelete) {
      onEventDrop(eventToDelete.id, null, null, true); // Pass true to indicate deletion
      setDeleteDialogOpen(false);
      setEventToDelete(null);
    }
  };

  const handleEditEvent = (event, e) => {
    e.stopPropagation(); // Prevent triggering the day click
    onEditEvent(event);
  };

  const handleConflictResolution = (proceed) => {
    if (proceed && conflictInfo) {
      onEventDrop(conflictInfo.eventId, conflictInfo.sourceDate, conflictInfo.destinationDate);
      setSnackbarMessage('Event moved with conflicts');
    }
    setConflictDialogOpen(false);
    setConflictInfo(null);
    setSnackbarOpen(true);
  };

  // Function to check if a date has events of the selected category
  const hasCategoryEvents = (date) => {
    if (!selectedCategory) return false;
    return events.some(event => 
      format(new Date(event.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd') &&
      event.category === selectedCategory
    );
  };

  // Function to get the category color
  const getCategoryColor = (category) => {
    switch (category) {
      case 'work':
        return '#4285f4';
      case 'personal':
        return '#34a853';
      case 'family':
        return '#ea4335';
      case 'other':
        return '#fbbc05';
      default:
        return '#6B8DE3';
    }
  };

  // Function to get events for a specific day
  const getEventsForDay = (day) => {
    if (!day) return [];
    const dayStr = format(day, 'yyyy-MM-dd');
    return events.filter(event => {
      try {
        const eventDate = new Date(event.date);
        return format(eventDate, 'yyyy-MM-dd') === dayStr;
      } catch (error) {
        console.error('Error filtering event:', error);
        return false;
      }
    });
  };

  const handleViewToggle = () => {
    setViewMode(prev => prev === 'month' ? 'week' : 'month');
  };

  const handleSyncCalendar = async () => {
    setSyncDialogOpen(true);
    setSyncStatus('syncing');
    try {
      if (!isGoogleCalendarInitialized) {
        throw new Error('Google Calendar not initialized. Please refresh the page and try again.');
      }

      if (!googleCalendarService.isSignedIn) {
        try {
          console.log('Attempting to sign in...');
          const signedIn = await googleCalendarService.signIn();
          if (!signedIn) {
            throw new Error('Failed to sign in to Google Calendar. Please try again.');
          }
          console.log('Successfully signed in');
        } catch (error) {
          console.error('Sign-in error:', error);
          if (error.error === 'popup_closed_by_user') {
            throw new Error('Sign-in was cancelled. Please try again.');
          }
          throw error;
        }
      }

      console.log('Starting sync process...');
      const result = await googleCalendarService.syncEvents(events);
      console.log('Sync completed:', result);
      
      setSnackbarMessage(`Successfully synced with Google Calendar: ${result.added} added, ${result.updated} updated, ${result.deleted} deleted`);
      setSyncStatus('success');
    } catch (error) {
      console.error('Error syncing with Google Calendar:', error);
      let errorMessage = 'Failed to sync with Google Calendar';
      
      if (error.message) {
        errorMessage = error.message;
      } else if (error.status === 403) {
        errorMessage = 'Permission denied. Please check your Google Calendar access permissions.';
      } else if (error.status === 401) {
        errorMessage = 'Authentication failed. Please sign in again.';
      }
      
      setSnackbarMessage(errorMessage);
      setSyncStatus('error');
    } finally {
      setTimeout(() => {
        setSyncDialogOpen(false);
        setSyncStatus('idle');
      }, 3000);
    }
  };

  useEffect(() => {
    const initializeGoogleCalendar = async () => {
      try {
        console.log('Initializing Google Calendar...');
        await googleCalendarService.init();
        setIsGoogleCalendarInitialized(true);
        console.log('Google Calendar initialized successfully');
      } catch (error) {
        console.error('Failed to initialize Google Calendar:', error);
        setSnackbarMessage('Failed to initialize Google Calendar. Please refresh the page.');
        setSnackbarOpen(true);
      }
    };

    initializeGoogleCalendar();
  }, []);

  const renderWeekView = () => {
    const startOfCurrentWeek = startOfWeek(currentDate);
    const weekDays = Array.from({ length: 7 }, (_, i) => addDays(startOfCurrentWeek, i));

    return (
      <Grid container sx={{ backgroundColor: '#fff', width: '100%' }}>
        <Grid container item xs={12} sx={{ width: '100%' }}>
          {weekDays.map((day, dayIndex) => {
            const eventsOnDay = filteredEvents.filter(event => 
              format(new Date(event.date), 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd')
            );
            
            return (
              <Grid 
                item 
                xs={12/7}
                key={dayIndex} 
                sx={{ 
                  height: '600px',
                  borderRight: '1px solid rgba(0,0,0,0.05)',
                  padding: '12px',
                  position: 'relative',
                  backgroundColor: isSameMonth(day, currentDate) ? '#fff' : '#f4f4f4',
                  cursor: 'pointer',
                  flex: '1 1 0',
                  transition: 'all 0.2s ease',
                  '&:hover': {
                    backgroundColor: isSameMonth(day, currentDate) ? 'rgba(26,115,232,0.04)' : '#f4f4f4',
                  }
                }} 
                onClick={() => handleDayClick(day)}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                  <Typography 
                    sx={{ 
                      color: isSameMonth(day, currentDate) ? 'text.primary' : 'text.secondary',
                      fontSize: '0.9rem',
                      fontWeight: 500,
                      ...(isToday(day) && {
                        color: 'white',
                        backgroundColor: 'primary.main',
                        borderRadius: '50%',
                        width: '24px',
                        height: '24px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 600
                      })
                    }}
                  >
                    {format(day, 'EEE d')}
                  </Typography>
                  {eventsOnDay.length > 0 && (
                    <Tooltip title="Add another event">
                      <IconButton
                        size="small"
                        onClick={(e) => handleAddEventOnDate(day, e)}
                        sx={{
                          padding: '2px',
                          color: 'primary.main',
                          backgroundColor: 'rgba(26,115,232,0.08)',
                          '&:hover': {
                            backgroundColor: 'rgba(26,115,232,0.12)',
                            transform: 'scale(1.1)'
                          }
                        }}
                      >
                        <AddIcon sx={{ fontSize: '0.9rem' }} />
                      </IconButton>
                    </Tooltip>
                  )}
                </Box>
                <Droppable droppableId={format(day, 'yyyy-MM-dd')}>
                  {(provided) => (
                    <div 
                      ref={provided.innerRef} 
                      {...provided.droppableProps} 
                      style={{ 
                        height: 'calc(100% - 40px)',
                        overflowY: 'auto'
                      }}
                    >
                      {getEventsForDay(day).map((event, index) => (
                        <Draggable key={event.id} draggableId={event.id} index={index}>
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              style={{
                                ...provided.draggableProps.style,
                                background: `linear-gradient(135deg, ${getCategoryColor(event.category)} 0%, ${getCategoryColor(event.category)}dd 100%)`,
                                color: 'white',
                                padding: '6px 12px',
                                borderRadius: '6px',
                                marginBottom: '4px',
                                fontSize: '0.8rem',
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                                transition: 'all 0.2s ease',
                                cursor: 'pointer',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                opacity: selectedCategory ? (event.category === selectedCategory ? 1 : 0.4) : 1
                              }}
                            >
                              <span>{event.title}</span>
                              <Box sx={{ display: 'flex', gap: 0.5 }}>
                                <Tooltip title="Edit event">
                                  <IconButton
                                    size="small"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onEditEvent(event);
                                    }}
                                    sx={{
                                      color: 'white',
                                      padding: '2px',
                                      '&:hover': {
                                        backgroundColor: 'rgba(255,255,255,0.2)',
                                      }
                                    }}
                                  >
                                    <EditIcon sx={{ fontSize: '0.9rem' }} />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title="Delete event">
                                  <IconButton
                                    size="small"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onEventDrop(event.id, format(day, 'yyyy-MM-dd'), null, true);
                                    }}
                                    sx={{
                                      color: 'white',
                                      padding: '2px',
                                      '&:hover': {
                                        backgroundColor: 'rgba(255,255,255,0.2)',
                                      }
                                    }}
                                  >
                                    <DeleteIcon sx={{ fontSize: '0.9rem' }} />
                                  </IconButton>
                                </Tooltip>
                              </Box>
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </Grid>
            );
          })}
        </Grid>
      </Grid>
    );
  };

  return (
    <>
      <Paper 
        elevation={3} 
        sx={{ 
          width: '100%', 
          margin: '20px auto', 
          borderRadius: '12px', 
          overflow: 'hidden',
          backgroundColor: '#fff',
          boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
          background: 'linear-gradient(to bottom, #ffffff, #f8f9fa)'
        }}
      >
        {/* Search and Filter Bar */}
        <Box sx={{ 
          p: 2, 
          borderBottom: '1px solid rgba(0,0,0,0.08)',
          background: 'linear-gradient(to right, #f8f9fa, #ffffff)',
          display: 'flex',
          gap: 2,
          alignItems: 'center'
        }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search events by title or description..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'primary.main' }} />
                </InputAdornment>
              ),
              endAdornment: searchQuery && (
                <InputAdornment position="end">
                  <IconButton
                    size="small"
                    onClick={clearFilters}
                    sx={{ color: 'text.secondary' }}
                  >
                    <ClearIcon />
                  </IconButton>
                </InputAdornment>
              )
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: '8px',
                backgroundColor: '#ffffff',
                transition: 'all 0.2s ease',
                '&:hover': {
                  backgroundColor: '#f1f3f4',
                  transform: 'translateY(-1px)',
                },
                '&.Mui-focused': {
                  backgroundColor: '#ffffff',
                  boxShadow: '0 1px 2px rgba(60,64,67,0.3), 0 1px 3px 1px rgba(60,64,67,0.15)',
                },
              },
            }}
          />
          <FormControl sx={{ minWidth: 120 }}>
            <Select
              value={selectedCategory}
              onChange={(e) => handleCategoryChange(e.target.value)}
              displayEmpty
              startAdornment={
                <InputAdornment position="start">
                  <FilterListIcon sx={{ color: 'primary.main' }} />
                </InputAdornment>
              }
              sx={{
                borderRadius: '8px',
                backgroundColor: '#ffffff',
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'rgba(0,0,0,0.1)',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'primary.main',
                },
              }}
            >
              {EVENT_CATEGORIES.map((category) => (
                <MenuItem key={category} value={category}>
                  {category}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Tooltip title={viewMode === 'month' ? 'Switch to Week View' : 'Switch to Month View'}>
              <IconButton
                onClick={handleViewToggle}
                sx={{
                  backgroundColor: 'rgba(26,115,232,0.08)',
                  '&:hover': {
                    backgroundColor: 'rgba(26,115,232,0.12)',
                  }
                }}
              >
                {viewMode === 'month' ? <ViewWeekIcon /> : <CalendarViewMonthIcon />}
              </IconButton>
            </Tooltip>
            <Tooltip title="Sync with Google Calendar">
              <IconButton
                onClick={handleSyncCalendar}
                sx={{
                  backgroundColor: 'rgba(26,115,232,0.08)',
                  '&:hover': {
                    backgroundColor: 'rgba(26,115,232,0.12)',
                  }
                }}
              >
                <SyncIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        {/* Active Filters Display */}
        {(searchQuery || selectedCategory !== 'All') && (
          <Box sx={{ 
            px: 2, 
            py: 1, 
            display: 'flex', 
            gap: 1, 
            alignItems: 'center',
            borderBottom: '1px solid rgba(0,0,0,0.08)',
            backgroundColor: 'rgba(26,115,232,0.04)'
          }}>
            <Typography variant="body2" color="text.secondary">
              Active filters:
            </Typography>
            {searchQuery && (
              <Chip
                label={`Search: "${searchQuery}"`}
                onDelete={() => setSearchQuery('')}
                size="small"
                sx={{ backgroundColor: 'rgba(26,115,232,0.1)' }}
              />
            )}
            {selectedCategory !== 'All' && (
              <Chip
                label={`Category: ${selectedCategory}`}
                onDelete={() => handleCategoryChange('All')}
                size="small"
                sx={{ backgroundColor: 'rgba(26,115,232,0.1)' }}
              />
            )}
          </Box>
        )}

        {/* Calendar Header */}
        <Box sx={{ 
          p: 2, 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between',
          borderBottom: '1px solid rgba(0,0,0,0.08)',
          background: 'linear-gradient(to right, #ffffff, #f8f9fa)'
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <IconButton 
              onClick={handlePrevMonth} 
              size="small"
              sx={{
                backgroundColor: 'rgba(26,115,232,0.08)',
                '&:hover': {
                  backgroundColor: 'rgba(26,115,232,0.12)',
                }
              }}
            >
              <ChevronLeftIcon sx={{ color: 'primary.main' }} />
            </IconButton>
            <Typography variant="h6" sx={{ 
              fontWeight: 500,
              color: 'text.primary',
              background: 'linear-gradient(45deg, #1a73e8, #34a853)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              {format(currentDate, 'MMMM yyyy')}
            </Typography>
            <IconButton 
              onClick={handleNextMonth} 
              size="small"
              sx={{
                backgroundColor: 'rgba(26,115,232,0.08)',
                '&:hover': {
                  backgroundColor: 'rgba(26,115,232,0.12)',
                }
              }}
            >
              <ChevronRightIcon sx={{ color: 'primary.main' }} />
            </IconButton>
          </Box>
          <IconButton 
            onClick={onAddEvent}
            sx={{ 
              backgroundColor: 'primary.main',
              color: 'white',
              '&:hover': { 
                backgroundColor: 'primary.dark',
                transform: 'scale(1.05)',
              },
              transition: 'all 0.2s ease'
            }}
          >
            <AddIcon />
          </IconButton>
        </Box>

        <DragDropContext onDragEnd={handleDragEnd}>
          {viewMode === 'month' ? (
            <Grid container sx={{ backgroundColor: '#fff', width: '100%' }}>
              {Array.from({ length: Math.ceil(daysInCalendar.length / 7) }).map((_, weekIndex) => (
                <Grid container item xs={12} key={weekIndex} sx={{ width: '100%' }}>
                  {daysInCalendar.slice(weekIndex * 7, (weekIndex + 1) * 7).map((day, dayIndex) => {
                    const eventsOnDay = filteredEvents.filter(event => 
                      format(new Date(event.date), 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd')
                    );
                    
                    return (
                      <Grid 
                        item 
                        xs={12/7}
                        key={dayIndex} 
                        sx={{ 
                          height: isMobile ? '80px' : '120px',
                          borderRight: '1px solid rgba(0,0,0,0.05)',
                          borderBottom: '1px solid rgba(0,0,0,0.05)',
                          padding: '12px',
                          position: 'relative',
                          backgroundColor: isSameMonth(day, currentDate) ? '#fff' : '#f4f4f4',
                          cursor: 'pointer',
                          flex: '1 1 0',
                          transition: 'all 0.2s ease',
                          '&:hover': {
                            backgroundColor: isSameMonth(day, currentDate) ? 'rgba(26,115,232,0.04)' : '#f4f4f4',
                            transform: 'translateY(-1px)',
                            boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                          },
                          ...(highlightedDate && isSameDay(day, highlightedDate) && {
                            backgroundColor: 'rgba(26,115,232,0.1)',
                            '&:hover': {
                              backgroundColor: 'rgba(26,115,232,0.15)'
                            }
                          }),
                          ...(day && hasCategoryEvents(day) && {
                            backgroundColor: `${getCategoryColor(selectedCategory)}10`,
                            border: `2px solid ${getCategoryColor(selectedCategory)}`,
                            '&:hover': {
                              backgroundColor: `${getCategoryColor(selectedCategory)}20`,
                            }
                          })
                        }} 
                        onClick={() => handleDayClick(day)}
                      >
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                          <Typography 
                            sx={{ 
                              color: isSameMonth(day, currentDate) ? 'text.primary' : 'text.secondary',
                              fontSize: '0.9rem',
                              fontWeight: 500,
                              ...(highlightedDate && isSameDay(day, highlightedDate) && {
                                color: 'primary.main',
                                fontWeight: 600
                              }),
                              ...(isToday(day) && {
                                color: 'white',
                                backgroundColor: 'primary.main',
                                borderRadius: '50%',
                                width: '24px',
                                height: '24px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontWeight: 600,
                                boxShadow: '0 2px 4px rgba(26,115,232,0.2)'
                              })
                            }}
                          >
                            {format(day, 'd')}
                          </Typography>
                          {eventsOnDay.length > 0 && (
                            <Tooltip title="Add another event">
                              <IconButton
                                size="small"
                                onClick={(e) => handleAddEventOnDate(day, e)}
                                sx={{
                                  padding: '2px',
                                  color: 'primary.main',
                                  backgroundColor: 'rgba(26,115,232,0.08)',
                                  '&:hover': {
                                    backgroundColor: 'rgba(26,115,232,0.12)',
                                    transform: 'scale(1.1)'
                                  },
                                  transition: 'all 0.2s ease'
                                }}
                              >
                                <AddIcon sx={{ fontSize: '0.9rem' }} />
                              </IconButton>
                            </Tooltip>
                          )}
                        </Box>
                        <Droppable droppableId={format(day, 'yyyy-MM-dd')}>
                          {(provided) => (
                            <div 
                              ref={provided.innerRef} 
                              {...provided.droppableProps} 
                              style={{ 
                                marginTop: '4px',
                                minHeight: '80px',
                                maxHeight: '80px',
                                overflowY: 'auto'
                              }}
                            >
                              {getEventsForDay(day).map((event, index) => (
                                <Draggable key={event.id} draggableId={event.id} index={index}>
                                  {(provided) => (
                                    <div
                                      ref={provided.innerRef}
                                      {...provided.draggableProps}
                                      {...provided.dragHandleProps}
                                      style={{
                                        ...provided.draggableProps.style,
                                        background: `linear-gradient(135deg, ${getCategoryColor(event.category)} 0%, ${getCategoryColor(event.category)}dd 100%)`,
                                        color: 'white',
                                        padding: '6px 12px',
                                        borderRadius: '6px',
                                        marginBottom: '4px',
                                        fontSize: '0.8rem',
                                        whiteSpace: 'nowrap',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                                        transition: 'all 0.2s ease',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        opacity: selectedCategory ? (event.category === selectedCategory ? 1 : 0.4) : 1
                                      }}
                                    >
                                      <span>{event.title}</span>
                                      <Box sx={{ display: 'flex', gap: 0.5 }}>
                                        <Tooltip title="Edit event">
                                          <IconButton
                                            size="small"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              onEditEvent(event);
                                            }}
                                            sx={{
                                              color: 'white',
                                              padding: '2px',
                                              '&:hover': {
                                                backgroundColor: 'rgba(255,255,255,0.2)',
                                              }
                                            }}
                                          >
                                            <EditIcon sx={{ fontSize: '0.9rem' }} />
                                          </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Delete event">
                                          <IconButton
                                            size="small"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              onEventDrop(event.id, format(day, 'yyyy-MM-dd'), null, true);
                                            }}
                                            sx={{
                                              color: 'white',
                                              padding: '2px',
                                              '&:hover': {
                                                backgroundColor: 'rgba(255,255,255,0.2)',
                                              }
                                            }}
                                          >
                                            <DeleteIcon sx={{ fontSize: '0.9rem' }} />
                                          </IconButton>
                                        </Tooltip>
                                      </Box>
                                    </div>
                                  )}
                                </Draggable>
                              ))}
                              {provided.placeholder}
                            </div>
                          )}
                        </Droppable>
                      </Grid>
                    );
                  })}
                </Grid>
              ))}
            </Grid>
          ) : (
            renderWeekView()
          )}
        </DragDropContext>
      </Paper>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleCloseDeleteDialog}
        PaperProps={{
          sx: {
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
          }
        }}
      >
        <DialogTitle sx={{ 
          color: 'error.main',
          fontWeight: 500,
          display: 'flex',
          alignItems: 'center',
          gap: 1
        }}>
          <DeleteIcon /> Delete Event
        </DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete the event "{eventToDelete?.title}"?
          </Typography>
        </DialogContent>
        <DialogActions sx={{ p: 2, pt: 0 }}>
          <Button 
            onClick={handleCloseDeleteDialog}
            sx={{ 
              color: 'text.secondary',
              '&:hover': {
                backgroundColor: 'rgba(0,0,0,0.04)'
              }
            }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleDeleteEvent}
            variant="contained"
            color="error"
            sx={{
              backgroundColor: 'error.main',
              '&:hover': {
                backgroundColor: 'error.dark'
              }
            }}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Conflict Dialog */}
      <Dialog open={conflictDialogOpen} onClose={() => handleConflictResolution(false)}>
        <DialogTitle>Event Conflict Detected</DialogTitle>
        <DialogContent>
          <Typography variant="body1" sx={{ mb: 2 }}>
            Moving this event will create conflicts with the following events:
          </Typography>
          {conflictInfo?.conflicts.map((event) => (
            <Typography key={event.id} variant="body2" sx={{ mb: 1 }}>
              • {event.title} ({event.time || 'No time specified'})
            </Typography>
          ))}
          <Typography variant="body2" color="warning.main" sx={{ mt: 2 }}>
            Would you like to proceed anyway?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => handleConflictResolution(false)} color="primary">
            Cancel
          </Button>
          <Button onClick={() => handleConflictResolution(true)} color="warning" variant="contained">
            Proceed Anyway
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSnackbarOpen(false)} severity={snackbarMessage.includes('conflicts') ? 'warning' : 'success'} sx={{ width: '100%' }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>

      {/* Sync Status Dialog */}
      <Dialog
        open={syncDialogOpen}
        PaperProps={{
          sx: {
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)'
          }
        }}
      >
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          {syncStatus === 'syncing' && (
            <>
              <CircularProgress size={40} sx={{ mb: 2 }} />
              <Typography>Syncing with Google Calendar...</Typography>
            </>
          )}
          {syncStatus === 'success' && (
            <>
              <CheckCircleIcon sx={{ color: 'success.main', fontSize: 40, mb: 2 }} />
              <Typography>Successfully synced with Google Calendar!</Typography>
            </>
          )}
          {syncStatus === 'error' && (
            <>
              <ErrorIcon sx={{ color: 'error.main', fontSize: 40, mb: 2 }} />
              <Typography color="error">Failed to sync with Google Calendar</Typography>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Calendar; 