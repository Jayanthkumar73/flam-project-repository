import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Stack,
  Typography
} from '@mui/material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

const RECURRENCE_OPTIONS = [
  { value: 'none', label: 'No Recurrence' },
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'custom', label: 'Custom' }
];

const EVENT_COLORS = [
  { value: '#4285f4', label: 'Blue' },
  { value: '#ea4335', label: 'Red' },
  { value: '#fbbc05', label: 'Yellow' },
  { value: '#34a853', label: 'Green' },
  { value: '#9c27b0', label: 'Purple' }
];

const EVENT_CATEGORIES = [
  'Work',
  'Personal',
  'Meeting',
  'Appointment',
  'Other'
];

const EventForm = ({ open, onClose, onSubmit, event = null }) => {
  const [formData, setFormData] = useState({
    id: '',
    title: '',
    description: '',
    date: '',
    time: '',
    recurrence: 'none',
    color: '#4285f4',
    weeklyDays: [],
    category: 'Other'
  });

  useEffect(() => {
    if (event) {
      setFormData({
        id: event.id,
        title: event.title,
        description: event.description || '',
        date: event.date,
        time: event.time || '',
        recurrence: event.recurrence || 'none',
        color: event.color || '#4285f4',
        weeklyDays: event.weeklyDays || [],
        category: event.category || 'Other'
      });
    } else {
      setFormData({
        id: Date.now().toString(),
        title: '',
        description: '',
        date: new Date().toISOString().split('T')[0],
        time: '',
        recurrence: 'none',
        color: '#4285f4',
        weeklyDays: [],
        category: 'Other'
      });
    }
  }, [event]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDateChange = (newDate) => {
    setFormData(prev => ({
      ...prev,
      date: newDate
    }));
  };

  const handleWeeklyDaysChange = (day) => {
    setFormData(prev => ({
      ...prev,
      weeklyDays: prev.weeklyDays.includes(day)
        ? prev.weeklyDays.filter(d => d !== day)
        : [...prev.weeklyDays, day]
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        {event ? 'Edit Event' : 'Add New Event'}
      </DialogTitle>
      <form onSubmit={handleSubmit}>
        <DialogContent>
          <Stack spacing={3}>
            <TextField
              name="title"
              label="Event Title"
              value={formData.title}
              onChange={handleChange}
              fullWidth
              required
              variant="outlined"
            />

            <TextField
              name="description"
              label="Description"
              value={formData.description}
              onChange={handleChange}
              fullWidth
              multiline
              rows={3}
              variant="outlined"
            />

            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DateTimePicker
                label="Date & Time"
                value={formData.date}
                onChange={handleDateChange}
                renderInput={(params) => <TextField {...params} fullWidth />}
              />
            </LocalizationProvider>

            <FormControl fullWidth>
              <InputLabel>Recurrence</InputLabel>
              <Select
                name="recurrence"
                value={formData.recurrence}
                onChange={handleChange}
                label="Recurrence"
              >
                {RECURRENCE_OPTIONS.map(option => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {formData.recurrence === 'weekly' && (
              <Box>
                <Typography variant="subtitle2" gutterBottom>
                  Repeat on:
                </Typography>
                <Stack direction="row" spacing={1}>
                  {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map(day => (
                    <Chip
                      key={day}
                      label={day}
                      onClick={() => handleWeeklyDaysChange(day)}
                      color={formData.weeklyDays.includes(day) ? 'primary' : 'default'}
                      variant={formData.weeklyDays.includes(day) ? 'filled' : 'outlined'}
                    />
                  ))}
                </Stack>
              </Box>
            )}

            <FormControl fullWidth>
              <InputLabel>Event Color</InputLabel>
              <Select
                name="color"
                value={formData.color}
                onChange={handleChange}
                label="Event Color"
              >
                {EVENT_COLORS.map(color => (
                  <MenuItem key={color.value} value={color.value}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box
                        sx={{
                          width: 20,
                          height: 20,
                          backgroundColor: color.value,
                          borderRadius: '50%'
                        }}
                      />
                      {color.label}
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl fullWidth>
              <InputLabel>Category</InputLabel>
              <Select
                name="category"
                value={formData.category}
                onChange={handleChange}
                label="Category"
              >
                {EVENT_CATEGORIES.map((category) => (
                  <MenuItem key={category} value={category}>
                    {category}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>Cancel</Button>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            disabled={!formData.title}
          >
            {event ? 'Update' : 'Add'} Event
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default EventForm; 