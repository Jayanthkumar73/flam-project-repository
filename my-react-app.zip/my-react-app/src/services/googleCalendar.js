// Google Calendar API configuration
const CLIENT_ID = '812791683002-cfvq2e58i24jjtuhm1314keti8scva78.apps.googleusercontent.com';
const API_KEY = 'AIzaSyAoyVa11Povt6RHRsIthVhjnZZ9GeZKNkU';
const DISCOVERY_DOCS = ['https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest'];
const SCOPES = 'https://www.googleapis.com/auth/calendar.events';

class GoogleCalendarService {
  constructor() {
    this.gapi = null;
    this.isSignedIn = false;
    this.isInitialized = false;
  }

  async init() {
    if (this.isInitialized) {
      console.log('Google Calendar API already initialized');
      return;
    }

    return new Promise((resolve, reject) => {
      // Check if gapi is already loaded
      if (window.gapi) {
        console.log('Google API already loaded, initializing...');
        this.initializeGapi(resolve, reject);
        return;
      }

      console.log('Loading Google API script...');
      const script = document.createElement('script');
      script.src = 'https://apis.google.com/js/api.js';
      script.async = true;
      script.defer = true;
      
      script.onload = () => {
        console.log('Google API script loaded, initializing...');
        this.initializeGapi(resolve, reject);
      };
      
      script.onerror = (error) => {
        console.error('Failed to load Google API script:', error);
        reject(new Error('Failed to load Google API script'));
      };
      
      document.body.appendChild(script);
    });
  }

  async initializeGapi(resolve, reject) {
    try {
      await window.gapi.load('client:auth2', async () => {
        try {
          console.log('Initializing Google Calendar API...');
          await window.gapi.client.init({
            apiKey: API_KEY,
            clientId: CLIENT_ID,
            discoveryDocs: DISCOVERY_DOCS,
            scope: SCOPES,
          });

          this.gapi = window.gapi;
          this.isSignedIn = this.gapi.auth2.getAuthInstance().isSignedIn.get();
          this.isInitialized = true;
          
          console.log('Google Calendar API initialized successfully');
          console.log('Sign-in status:', this.isSignedIn);
          
          // Listen for sign-in state changes
          this.gapi.auth2.getAuthInstance().isSignedIn.listen((isSignedIn) => {
            console.log('Sign-in state changed:', isSignedIn);
            this.isSignedIn = isSignedIn;
          });

          resolve();
        } catch (error) {
          console.error('Failed to initialize Google Calendar API:', error);
          reject(error);
        }
      });
    } catch (error) {
      console.error('Failed to load client:auth2:', error);
      reject(error);
    }
  }

  async signIn() {
    if (!this.gapi || !this.isInitialized) {
      console.error('Google API not initialized');
      throw new Error('Google API not initialized. Please refresh the page and try again.');
    }

    try {
      console.log('Attempting to sign in...');
      const authInstance = this.gapi.auth2.getAuthInstance();
      const googleUser = await authInstance.signIn();
      console.log('Successfully signed in:', googleUser.getBasicProfile().getEmail());
      return true;
    } catch (error) {
      console.error('Error signing in:', error);
      if (error.error === 'popup_closed_by_user') {
        throw new Error('Sign-in was cancelled. Please try again.');
      }
      throw error;
    }
  }

  async signOut() {
    if (!this.gapi) {
      throw new Error('Google API not initialized');
    }
    try {
      await this.gapi.auth2.getAuthInstance().signOut();
      return true;
    } catch (error) {
      console.error('Error signing out:', error);
      return false;
    }
  }

  async syncEvents(events) {
    if (!this.gapi || !this.isInitialized) {
      console.error('Google API not initialized');
      throw new Error('Google API not initialized. Please refresh the page and try again.');
    }
    
    if (!this.isSignedIn) {
      console.error('User not signed in');
      throw new Error('Not signed in to Google Calendar. Please sign in first.');
    }

    try {
      console.log('Starting event sync...');
      // Get existing events from Google Calendar
      const response = await this.gapi.client.calendar.events.list({
        calendarId: 'primary',
        timeMin: new Date().toISOString(),
        maxResults: 100,
        singleEvents: true,
        orderBy: 'startTime',
      });

      console.log('Retrieved events from Google Calendar:', response.result.items.length);
      const existingEvents = response.result.items;
      const eventsToAdd = [];
      const eventsToUpdate = [];
      const eventsToDelete = [];

      // Compare local events with Google Calendar events
      events.forEach(localEvent => {
        const googleEvent = existingEvents.find(e => e.description === localEvent.id);
        if (!googleEvent) {
          eventsToAdd.push(localEvent);
        } else if (this.hasEventChanged(localEvent, googleEvent)) {
          eventsToUpdate.push({ ...localEvent, googleEventId: googleEvent.id });
        }
      });

      // Find events to delete (events in Google Calendar but not in local events)
      existingEvents.forEach(googleEvent => {
        if (!events.find(e => e.id === googleEvent.description)) {
          eventsToDelete.push(googleEvent.id);
        }
      });

      console.log('Sync operations:', {
        toAdd: eventsToAdd.length,
        toUpdate: eventsToUpdate.length,
        toDelete: eventsToDelete.length
      });

      // Perform sync operations
      await Promise.all([
        ...eventsToAdd.map(event => this.addEvent(event)),
        ...eventsToUpdate.map(event => this.updateEvent(event)),
        ...eventsToDelete.map(eventId => this.deleteEvent(eventId)),
      ]);

      console.log('Sync completed successfully');
      return {
        added: eventsToAdd.length,
        updated: eventsToUpdate.length,
        deleted: eventsToDelete.length,
      };
    } catch (error) {
      console.error('Error syncing events:', error);
      if (error.status === 403) {
        throw new Error('Permission denied. Please check your Google Calendar access permissions.');
      } else if (error.status === 401) {
        throw new Error('Authentication failed. Please sign in again.');
      } else {
        throw error;
      }
    }
  }

  async addEvent(event) {
    if (!this.gapi || !this.isSignedIn) {
      throw new Error('Not signed in to Google Calendar');
    }

    try {
      const googleEvent = this.convertToGoogleEvent(event);
      await this.gapi.client.calendar.events.insert({
        calendarId: 'primary',
        resource: googleEvent,
      });
    } catch (error) {
      console.error('Error adding event:', error);
      throw error;
    }
  }

  async updateEvent(event) {
    if (!this.gapi || !this.isSignedIn) {
      throw new Error('Not signed in to Google Calendar');
    }

    try {
      const googleEvent = this.convertToGoogleEvent(event);
      await this.gapi.client.calendar.events.update({
        calendarId: 'primary',
        eventId: event.googleEventId,
        resource: googleEvent,
      });
    } catch (error) {
      console.error('Error updating event:', error);
      throw error;
    }
  }

  async deleteEvent(eventId) {
    if (!this.gapi || !this.isSignedIn) {
      throw new Error('Not signed in to Google Calendar');
    }

    try {
      await this.gapi.client.calendar.events.delete({
        calendarId: 'primary',
        eventId: eventId,
      });
    } catch (error) {
      console.error('Error deleting event:', error);
      throw error;
    }
  }

  convertToGoogleEvent(event) {
    const [startTime, endTime] = event.time ? event.time.split(' - ') : ['00:00', '23:59'];
    const startDate = new Date(event.date);
    const endDate = new Date(event.date);
    
    startDate.setHours(parseInt(startTime.split(':')[0]), parseInt(startTime.split(':')[1]));
    endDate.setHours(parseInt(endTime.split(':')[0]), parseInt(endTime.split(':')[1]));

    return {
      summary: event.title,
      description: event.id, // Store local event ID in description
      start: {
        dateTime: startDate.toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      end: {
        dateTime: endDate.toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      colorId: this.getGoogleCalendarColorId(event.category),
      extendedProperties: {
        private: {
          category: event.category,
        },
      },
    };
  }

  hasEventChanged(localEvent, googleEvent) {
    const localStart = new Date(localEvent.date + 'T' + localEvent.time.split(' - ')[0]);
    const googleStart = new Date(googleEvent.start.dateTime);
    
    return (
      localEvent.title !== googleEvent.summary ||
      localStart.getTime() !== googleStart.getTime() ||
      localEvent.category !== googleEvent.extendedProperties?.private?.category
    );
  }

  getGoogleCalendarColorId(category) {
    // Map local categories to Google Calendar color IDs
    const colorMap = {
      'Work': '1',    // Blue
      'Personal': '2', // Green
      'Meeting': '3',  // Red
      'Appointment': '4', // Yellow
      'Other': '5',   // Orange
    };
    return colorMap[category] || '1';
  }
}

export const googleCalendarService = new GoogleCalendarService(); 