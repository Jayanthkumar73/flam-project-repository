const DB_NAME = 'CalendarDB';
const DB_VERSION = 1;
const STORE_NAME = 'events';

class CalendarDB {
  constructor() {
    this.db = null;
    this.initPromise = null;
  }

  async init() {
    if (this.db) {
      return this.db;
    }

    if (this.initPromise) {
      return this.initPromise;
    }

    this.initPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = (event) => {
        console.error('Database error:', event.target.error);
        this.initPromise = null;
        reject(new Error('Failed to open database: ' + event.target.error.message));
      };

      request.onsuccess = (event) => {
        this.db = event.target.result;
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          store.createIndex('date', 'date', { unique: false });
        }
      };
    });

    return this.initPromise;
  }

  async ensureDB() {
    if (!this.db) {
      await this.init();
    }
    return this.db;
  }

  async saveEvents(events) {
    try {
      const db = await this.ensureDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);

        // Clear existing events
        store.clear();

        // Add all events
        events.forEach(event => {
          store.add(event);
        });

        transaction.oncomplete = () => {
          resolve(true);
        };

        transaction.onerror = (event) => {
          console.error('Error saving events:', event.target.error);
          reject(new Error('Failed to save events: ' + event.target.error.message));
        };
      });
    } catch (error) {
      console.error('Error in saveEvents:', error);
      throw error;
    }
  }

  async getEvents() {
    try {
      const db = await this.ensureDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onsuccess = () => {
          resolve(request.result || []);
        };

        request.onerror = (event) => {
          console.error('Error getting events:', event.target.error);
          reject(new Error('Failed to get events: ' + event.target.error.message));
        };
      });
    } catch (error) {
      console.error('Error in getEvents:', error);
      throw error;
    }
  }

  async addEvent(event) {
    try {
      const db = await this.ensureDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.add(event);

        request.onsuccess = () => {
          resolve(true);
        };

        request.onerror = (event) => {
          console.error('Error adding event:', event.target.error);
          reject(new Error('Failed to add event: ' + event.target.error.message));
        };
      });
    } catch (error) {
      console.error('Error in addEvent:', error);
      throw error;
    }
  }

  async updateEvent(event) {
    try {
      const db = await this.ensureDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.put(event);

        request.onsuccess = () => {
          resolve(true);
        };

        request.onerror = (event) => {
          console.error('Error updating event:', event.target.error);
          reject(new Error('Failed to update event: ' + event.target.error.message));
        };
      });
    } catch (error) {
      console.error('Error in updateEvent:', error);
      throw error;
    }
  }

  async deleteEvent(eventId) {
    try {
      const db = await this.ensureDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.delete(eventId);

        request.onsuccess = () => {
          resolve(true);
        };

        request.onerror = (event) => {
          console.error('Error deleting event:', event.target.error);
          reject(new Error('Failed to delete event: ' + event.target.error.message));
        };
      });
    } catch (error) {
      console.error('Error in deleteEvent:', error);
      throw error;
    }
  }
}

export const calendarDB = new CalendarDB(); 